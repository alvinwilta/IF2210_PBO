//driverbottle.cpp
/*
    Nama: Alvin Wilta
    NIM: 13519163
    Kelas: 03
    Tanggal: 10/02/2021
    Topik: Kuis
*/

//g++ -o <nama exe> <semua file cpp>

#include <iostream>
using namespace std;
#include "DeretLampu.hpp"
#include "Lampu.h"

int main() {
    Deret_Lampu *D = new Deret_Lampu();
    
}