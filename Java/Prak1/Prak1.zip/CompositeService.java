public class CompositeService extends AbstractService {
    private ArrayList<AbstractService> serviceList;

    public CompositeService(String name) {
        super(name);
    }

    public getServices() {
        
    }
}
